setwd("C:/Users/sasmi/OneDrive/Desktop/it24101660")
shareholders <- c(135, 146, 152, 168, 172, 177, 182,
                  190, 195, 203, 212, 218, 225, 230,
                  240, 248, 255, 262, 269)
breaks_share <- seq(130, 270, by = 20)
hist(shareholders,
     breaks = breaks_share,
     right = FALSE,
     include.lowest = TRUE,
     main = "Histogram of Shareholders",
     xlab = "Shareholders (in thousands)",
     ylab = "Frequency")
axis(1, at = breaks_share)
classes_share <- cut(shareholders, breaks = breaks_share, right = FALSE, include.lowest = TRUE)
freq_tbl_share <- as.data.frame(table(classes_share))
names(freq_tbl_share) <- c("Class", "Frequency")
freq_tbl_share$RelativeFreq <- freq_tbl_share$Frequency / sum(freq_tbl_share$Frequency)
freq_tbl_share$CumulativeFreq <- cumsum(freq_tbl_share$Frequency)
freq_tbl_share$CumulativePercent <- 100 * freq_tbl_share$CumulativeFreq / sum(freq_tbl_share$Frequency)
print(freq_tbl_share)

mean(shareholders)
median(shareholders)

mids_share <- (head(breaks_share, -1) + tail(breaks_share, -1)) / 2
freqs_share <- freq_tbl_share$Frequency
plot(mids_share, freqs_share,
     type = "b", pch = 16,
     main = "Frequency Polygon - Shareholders",
     xlab = "Class Mid-points",
     ylab = "Frequency")

upper_bounds_share <- tail(breaks_share, -1)
cum_freq_share <- cumsum(freqs_share)
ogive_x_share <- c(breaks_share[1], upper_bounds_share)
ogive_y_share <- c(0, cum_freq_share)
plot(ogive_x_share, ogive_y_share, type = "s", lwd = 2,
     main = "Ogive - Shareholders",
     xlab = "Shareholders (in thousands)",
     ylab = "Cumulative Frequency")
points(ogive_x_share, ogive_y_share, pch = 16)



