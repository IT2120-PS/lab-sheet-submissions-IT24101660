setwd("C:/Users/sasmi/OneDrive/Desktop/it24101660")

# Step 2: Import the dataset
DeliveryTimes <- read.table("Exercise - Lab 05.txt", header = FALSE)
names(DeliveryTimes) <- "DeliveryTime"
DeliveryTimes$DeliveryTime <- as.numeric(as.character(DeliveryTimes$DeliveryTime))
x <- DeliveryTimes$DeliveryTime

# Step 3: Histogram (9 classes, 20–70, right-open)
breaks1 <- seq(20, 70, length.out = 10)
hist(x,
     breaks = breaks1,
     right = FALSE,
     include.lowest = TRUE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time",
     ylab = "Frequency")
axis(1, at = breaks1)

# Step 4: Frequency distribution
classes <- cut(x, breaks = breaks1, right = FALSE, include.lowest = TRUE)
freq_tbl <- as.data.frame(table(classes))
names(freq_tbl) <- c("Class", "Frequency")
freq_tbl$RelativeFreq <- freq_tbl$Frequency / sum(freq_tbl$Frequency)
freq_tbl$CumulativeFreq <- cumsum(freq_tbl$Frequency)
freq_tbl$CumulativePercent <- 100 * freq_tbl$CumulativeFreq / sum(freq_tbl$Frequency)
print(freq_tbl)

# Step 5: Mean and Median
mean(x, na.rm = TRUE)
median(x, na.rm = TRUE)

# Step 6: Frequency polygon
mids <- (head(breaks1, -1) + tail(breaks1, -1)) / 2
freqs <- freq_tbl$Frequency
plot(mids, freqs,
     type = "b", pch = 16,
     main = "Frequency Polygon - Delivery Times",
     xlab = "Class Mid-points",
     ylab = "Frequency")

# Step 7: Cumulative frequency polygon (Ogive)
upper_bounds <- tail(breaks1, -1)
cum_freq <- cumsum(freqs)
ogive_x <- c(breaks1[1], upper_bounds)
ogive_y <- c(0, cum_freq)
plot(ogive_x, ogive_y, type = "s", lwd = 2,
     main = "Ogive - Delivery Times",
     xlab = "Delivery Time",
     ylab = "Cumulative Frequency")
points(ogive_x, ogive_y, pch = 16)

