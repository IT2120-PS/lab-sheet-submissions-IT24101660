setwd("C:\\Users\\sasmi\\OneDrive\\Desktop\\IT24101660")
punif(10, min=0, max=30)
1 - punif(20, min=0, max=30)

rate <- 1/2

# Q2.i
pexp(3, rate=rate, lower.tail=TRUE)

# Q2.ii
pexp(4, rate=rate, lower.tail=FALSE)

# Q2.iii
pexp(4, rate=rate) - pexp(2, rate=rate)

mu <- 36.8
sigma <- 0.4

# Q3.i
pnorm(37.9, mean=mu, sd=sigma, lower.tail=FALSE)

# Q3.ii
pnorm(36.9, mean=mu, sd=sigma) - pnorm(36.4, mean=mu, sd=sigma)

# Q3.iii
qnorm(0.012, mean=mu, sd=sigma)

# Q3.iv
qnorm(0.99, mean=mu, sd=sigma)


# Ex1. Uniform (0–40)
punif(25, min=0, max=40) - punif(10, min=0, max=40)

# Ex2. Exponential (λ = 1/3)
pexp(2, rate=1/3, lower.tail=TRUE)

# Ex3.i Normal (IQ ~ N(100,15))
pnorm(130, mean=100, sd=15, lower.tail=FALSE)

# Ex3.ii
qnorm(0.95, mean=100, sd=15)







